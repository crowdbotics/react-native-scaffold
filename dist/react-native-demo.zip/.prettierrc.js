module.exports = {
  semi: false,
  parser: "babel",
  trailingComma: "none",
  arrowParens: "avoid"
}
